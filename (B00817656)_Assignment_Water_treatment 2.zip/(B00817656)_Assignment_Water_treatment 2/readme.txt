
Cs-535-02 Introduction to Data Mining
Name: Sushma Hanumanthu
B Number: B00817656
Email id: shanuma1@binghamton.edu


All the coding is done on Jupyter Notebook/Script (Python)

Go to kaggle.com first, open the kernel as notebook python, then upload the file through 'File' option and then upload the data file 

kaggle.com/notebooks